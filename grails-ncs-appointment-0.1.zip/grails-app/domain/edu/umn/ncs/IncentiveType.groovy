package edu.umn.ncs

class IncentiveType {
	
	String name
	
	String toString() { name }
}
