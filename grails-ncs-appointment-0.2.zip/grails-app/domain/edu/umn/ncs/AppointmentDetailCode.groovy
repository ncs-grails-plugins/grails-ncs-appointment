package edu.umn.ncs

class AppointmentDetailCode {
	
	String name
	
    static constraints = {
    }
}
